#!/usr/bin/env python3
"""Phase 1A — NSE validation with discovery pipeline performance profiling."""

from __future__ import annotations

import json
import pickle
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from statistics import mean, median
from typing import Any
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

CACHE_DIR = ROOT / "data" / "history_cache"


def _bootstrap(aq, scoring_v2: bool = True) -> None:
    ss = aq.st.session_state
    registry = list(ss.get("strategy_registry", []))
    ss.clear()
    ss["strategy_registry"] = registry
    ss["paper_capital"] = 500_000.0
    ss["paper_broker"] = {
        "connected": False, "cash": 500_000.0, "starting_capital": 500_000.0,
        "positions": {}, "orders": {}, "trade_history": [], "realized_pnl": 0.0, "risk": {},
    }
    ss["paper_positions"] = {}
    ss["trade_candidates"] = {}
    ss["final_trade_list"] = []
    ss["selected_portfolio"] = []
    ss["market_data"] = {}
    ss["stock_objects"] = {}
    ss["waiting_entry"] = {}
    ss["candidate_rejections"] = {}
    ss["pipeline_stage_counts"] = {}
    ss["indicator_frame_cache"] = {}
    aq.WORKSPACE.preferences.update({
        "scoring_engine_version": "V2" if scoring_v2 else "V1",
        "execution_mode": "PAPER",
        "operating_mode": "Fast Scan",
        "minimum_fast_ai_score": 70,
        "minimum_confidence": 70,
        "discovery_focus_limit_fast": 28,
    })


def _liquid10() -> list[str]:
    return [
        "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
        "SBIN.NS", "BHARTIARTL.NS", "ITC.NS", "LT.NS", "AXISBANK.NS",
    ]


def _fetch_symbols(aq, symbols: list[str]) -> tuple[dict[str, Any], float]:
    import yfinance as yf

    t0 = time.perf_counter()
    prepared = {}
    failures = []
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def _one(sym: str):
        cache_file = CACHE_DIR / f"{sym.replace('.NS', '')}.pkl"
        try:
            if cache_file.exists():
                raw = pickle.loads(cache_file.read_bytes())
            else:
                raw = yf.download(sym, period="1y", interval="1d", progress=False, auto_adjust=True, threads=False)
                if raw is not None and not raw.empty:
                    cache_file.write_bytes(pickle.dumps(raw))
            if raw is None or raw.empty:
                return sym, None, "NO_HISTORY"
            if hasattr(raw.columns, "nlevels") and raw.columns.nlevels > 1:
                raw.columns = raw.columns.get_level_values(0)
            df = aq.calculate_indicators(raw)
            if df is None or df.empty:
                return sym, None, "INDICATOR_FAIL"
            return sym, df, None
        except Exception as exc:
            return sym, None, str(type(exc).__name__)

    with ThreadPoolExecutor(max_workers=min(8, max(1, len(symbols)))) as pool:
        for sym, df, err in pool.map(_one, symbols):
            if df is not None:
                prepared[sym] = df
            elif err:
                failures.append({"symbol": sym, "reason": err})
    return {"data": prepared, "failures": failures}, time.perf_counter() - t0


def _nifty50_symbols(aq) -> list[str]:
    try:
        symbols = aq.fetch_index_constituents(aq.NSE_INDEX_SOURCES["Nifty50"])
        return sorted({f"{s}.NS" if not str(s).endswith(".NS") else s for s in symbols})
    except Exception:
        return [f"{s}.NS" for s in aq._NIFTY50_SEED]


def _run_universe(aq, symbols: list[str], label: str) -> dict[str, Any]:
    from discovery.pipeline import DiscoveryPipeline

    wall = time.perf_counter()
    fetch_result, fetch_s = _fetch_symbols(aq, symbols)
    market_data = fetch_result["data"]
    aq.st.session_state.market_data = market_data

    try:
        aq.fetch_nifty_benchmark()
    except Exception:
        pass

    disc = DiscoveryPipeline(aq).run(market_data)
    t4 = time.perf_counter()
    with patch.object(aq, "is_market_open", return_value=True):
        final = aq.build_ai_consensus()
    scoring_s = time.perf_counter() - t4

    stats = {
        "label": label,
        "symbols_requested": len(symbols),
        "symbols_with_usable_data": len(market_data),
        "fetch_wall_seconds": round(fetch_s, 3),
        "failures": fetch_result["failures"],
        "fast_screen_before_style": {
            "input": len(market_data),
            "survivors_old_logic": sum(
                1 for df in market_data.values()
                if len(df) >= 50
                and float(df.iloc[-1]["Close"]) >= aq.CONFIG.get("MIN_PRICE", 20)
                and float(df["Volume"].tail(20).mean()) >= aq.CONFIG.get("MIN_AVG_VOLUME", 100000)
            ),
        },
        "eligible": disc.eligible_count,
        "focus": disc.focus_count,
        "strategy_evaluated": disc.strategy_evaluated,
        "strategy_signals": disc.strategy_signals,
        "eligibility_audit": disc.eligibility_audit.to_dict(),
        "focus_meta": disc.focus_meta,
        "candidates": len(final or []),
        "scores": [],
        "timings": {**disc.timings.as_dict(), "history_cache": round(fetch_s, 3), "scoring_v2_risk": round(scoring_s, 3)},
        "total_wall_seconds": 0.0,
    }

    for trade in final or []:
        stats["scores"].append(float(getattr(trade, "ai_score", 0) or 0))

    stats["distribution"] = _distribution(stats["scores"])
    stats["score_summary"] = _summary(stats["scores"])
    stats["total_wall_seconds"] = round(time.perf_counter() - wall, 3)
    return stats


def _distribution(scores: list[float]) -> dict[str, int]:
    buckets = {"0-39": 0, "40-49": 0, "50-59": 0, "60-69": 0, "70-79": 0, "80-89": 0, "90-100": 0}
    for s in scores:
        if s < 40:
            buckets["0-39"] += 1
        elif s < 50:
            buckets["40-49"] += 1
        elif s < 60:
            buckets["50-59"] += 1
        elif s < 70:
            buckets["60-69"] += 1
        elif s < 80:
            buckets["70-79"] += 1
        elif s < 90:
            buckets["80-89"] += 1
        else:
            buckets["90-100"] += 1
    return buckets


def _summary(scores: list[float]) -> dict[str, float | None]:
    if not scores:
        return {"mean": None, "median": None, "highest": None, "lowest": None}
    return {
        "mean": round(mean(scores), 2),
        "median": round(median(scores), 2),
        "highest": round(max(scores), 2),
        "lowest": round(min(scores), 2),
    }


def main() -> int:
    import appemergentquant_v3_1 as aq

    _bootstrap(aq, scoring_v2=True)
    report = {"phase": "1A", "pipeline": "discovery", "universes": []}
    for label, symbols in [
        ("liquid_10", _liquid10()),
        ("nifty_50", _nifty50_symbols(aq)[:50]),
    ]:
        report["universes"].append(_run_universe(aq, symbols, label))

    try:
        n200 = sorted({f"{s}.NS" if not str(s).endswith('.NS') else s for s in aq.fetch_index_constituents(aq.NSE_INDEX_SOURCES["Nifty200"])})
        if len(n200) >= 100:
            _bootstrap(aq, scoring_v2=True)
            report["universes"].append(_run_universe(aq, n200[:200], "nifty_200"))
    except Exception as exc:
        report["nifty_200_skipped"] = str(exc)

    print(json.dumps(report, indent=2, default=str))
    bounded_ok = all(0 <= s <= 100 for u in report["universes"] for s in u.get("scores", []))
    return 0 if bounded_ok and report["universes"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
